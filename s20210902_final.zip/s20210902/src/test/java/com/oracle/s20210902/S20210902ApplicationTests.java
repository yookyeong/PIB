package com.oracle.s20210902;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S20210902ApplicationTests {

	@Test
	void contextLoads() {
	}

}
