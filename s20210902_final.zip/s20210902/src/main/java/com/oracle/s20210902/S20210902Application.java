package com.oracle.s20210902;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S20210902Application {

	public static void main(String[] args) {
		SpringApplication.run(S20210902Application.class, args);
	}

}
