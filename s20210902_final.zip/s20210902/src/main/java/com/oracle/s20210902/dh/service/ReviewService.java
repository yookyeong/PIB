package com.oracle.s20210902.dh.service;

import com.oracle.s20210902.model.Review;

public interface ReviewService {

	int insert(Review review);

	int delete(Review review);

	
}
