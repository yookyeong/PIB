package com.oracle.s20210902.model;

import lombok.Setter;

import lombok.Getter;

@Getter
@Setter
public class Common {
	private int bcode;
	private int mcode;
	private String content;
}
