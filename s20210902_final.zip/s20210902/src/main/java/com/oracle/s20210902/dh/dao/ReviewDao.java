package com.oracle.s20210902.dh.dao;

import com.oracle.s20210902.model.Review;

public interface ReviewDao {

	int insert(Review review);

	int delete(Review review);


	
	
}
